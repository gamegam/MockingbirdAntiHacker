<?php

namespace ethaniccc\Mockingbird\detections\movement;

interface CancellableMovement{
}